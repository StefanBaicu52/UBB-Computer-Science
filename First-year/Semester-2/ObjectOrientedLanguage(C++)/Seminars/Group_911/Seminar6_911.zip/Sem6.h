#pragma once

#include <QtWidgets/QWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include "ui_Sem6.h"
#include "Service.h"

class Sem6 : public QWidget
{
    Q_OBJECT
public:
    Sem6(Service service);
    ~Sem6();

private:
    Service service;
    Ui::Sem6Class ui;
    QListWidget *songsListW;
    QLineEdit *artistLE;
    QLineEdit *titleLE;
    QLineEdit *minutesLE;
    QLineEdit *secondsLE;
    QLineEdit *sourceLE;


    void setupUI();
    void populateList();
    QVBoxLayout* createOperationsLayout();
    void handleAddButton();
    void handleRemoveButton();
};
