#include "Sem6.h"
#include <qboxlayout.h>
#include <QtWidgets/QLabel>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QMessageBox>
#include <string>
#include <exception>
#include <sstream>

Sem6::Sem6(Service service) : service(service)
{
    /*ui.setupUi(this);
    ui.lineEdit->setText("hello!");*/
    this->setupUI();
}

void Sem6::setupUI()
{
    QHBoxLayout* mainLayout = new QHBoxLayout{ this };
    /*QHBoxLayout* mainLayout2 = new QHBoxLayout{ this };
    QLabel *testLabel = new QLabel{ "test" };
    mainLayout2->addWidget(testLabel);*/
    this->songsListW = new QListWidget{};
    this->populateList();
    mainLayout->addWidget(songsListW);
    mainLayout->addLayout(createOperationsLayout());
    //mainLayout->addLayout(mainLayout2);
}

QVBoxLayout* Sem6::createOperationsLayout() 
{
    QVBoxLayout *mainLayout = new QVBoxLayout{};
    QFormLayout *formLayout = new QFormLayout{};
    QLabel *artistLabel = new QLabel{ "Artist" };
    QLabel *titleLabel = new QLabel{ "Title" };
    QLabel *minutesLabel = new QLabel{ "Minutes" };
    QLabel *secondsLabel = new QLabel{ "Seconds" };
    QLabel *sourceLabel = new QLabel{ "Source" };
    this->artistLE = new QLineEdit();
    this->titleLE = new QLineEdit();
    this->minutesLE = new QLineEdit();
    this->secondsLE = new QLineEdit();
    this->sourceLE = new QLineEdit();
    formLayout->addRow(artistLabel, this->artistLE);
    formLayout->addRow(titleLabel, this->titleLE);
    formLayout->addRow(minutesLabel, this->minutesLE);
    formLayout->addRow(secondsLabel, this->secondsLE);
    formLayout->addRow(sourceLabel, this->sourceLE);
    mainLayout->addLayout(formLayout);

    QPushButton *addButton = new QPushButton{ "Add" };
    connect(addButton, &QPushButton::clicked, this, &Sem6::handleAddButton);
    QPushButton *removeButton = new QPushButton{ "Remove" };
    connect(removeButton, &QPushButton::clicked, this, &Sem6::handleRemoveButton);
    mainLayout->addWidget(addButton);
    mainLayout->addWidget(removeButton);
    return mainLayout;
}

void Sem6::handleAddButton()
{
    try {
        std::string artist = this->artistLE->text().toStdString();
        std::string title = this->titleLE->text().toStdString();
        double minutes = stod(this->minutesLE->text().toStdString());
        double seconds = stod(this->secondsLE->text().toStdString());
        std::string source = this->sourceLE->text().toStdString();
        service.addSongToRepository(artist, title, minutes, seconds, source);
        this->populateList();
    }
    catch (std::exception e)
    {
        QMessageBox *messageBox = new QMessageBox{};
        messageBox->setWindowTitle("Error when adding!");
        messageBox->setText(e.what());
        messageBox->exec();
    }
}

void Sem6::populateList()
{
    std::vector<Song> songs = this->service.getRepo().getSongs();
    this->songsListW->clear();
    for (int i = 0; i < songs.size(); ++i)
    {
        std::stringstream stream;
        stream << songs[i];
        new QListWidgetItem(tr(stream.str().c_str()), songsListW);
    }

    
}


void Sem6::handleRemoveButton() {
    this->service.removeSongFromRepository(this->artistLE->text().toStdString(),this->titleLE->text().toStdString());
    this->populateList();
}

Sem6::~Sem6()
{}
