#include "Sem6.h"
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include "Service.h"
#include "CSVPlaylist.h"
#include "RepositoryExceptions.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

	Repository repo("Songs.txt");
	FilePlaylist *p = new CSVPlaylist{};
	Service serv(repo, p, SongValidator{});

	Sem6 w{ serv };
	w.show();

    return a.exec();
}
