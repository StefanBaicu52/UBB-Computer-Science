#pragma once
class Action {
public:
	virtual ~Action() {}
	virtual void executeUndo() = 0;
	virtual void executeRedo() = 0;
};
class ActionAdd : public Action {
	void executeUndo() override {}
	void executeRedo() override {}
};