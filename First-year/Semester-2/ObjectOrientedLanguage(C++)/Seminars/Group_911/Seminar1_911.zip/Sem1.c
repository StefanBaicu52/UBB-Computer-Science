#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>

void GetSumAndProduct(int a, int b, int *sum, int* prod)
{
    *sum = a + b;
    *prod = a * b;
}

int main()
{
    // Write a program which prints the sum of two given integer numbers.

    //int a, b;
    //int sum = 0;
    //printf("Enter first number: ");
    //scanf("%d", &a);

    //printf("Enter second number: ");
    //scanf("%d", &b);

    //sum = a + b;
    //printf("The sum is: %d\n", sum);


    /*
        Write a program which asks for your name and surname.
        - The application will print a greeting containing your entire name, 
        - as well as the number of characters your entire name contains.
    */

    //char surname[51];
    //printf("Enter your surname: ");
    //scanf("%s50", surname);
    //surname[0] = toupper(surname[0]);

    //char firstName[51];
    //printf("Enter your first name: ");
    //scanf("%s50", firstName);
    //firstName[0] = toupper(firstName[0]);

    //strcat(firstName, " ");
    //printf("Hello %s! :) \n", strcat(firstName, surname));

    //printf("Your name has %d characters.\n", strlen(firstName) - 1);


    /*
        Create a C function that receives as input 2 integer numbers 
        and returns their sum and their product.
    */


    int a, b;
    int sum = 0, prod = 1;
    printf("Enter first number: ");
    scanf("%d", &a);

    system("pause");

    printf("Enter second number: ");
    scanf("%d", &b);
    GetSumAndProduct(a, b, &sum, &prod);
    printf("Sum is: %d; prod is: %d\n", sum, prod);
}
