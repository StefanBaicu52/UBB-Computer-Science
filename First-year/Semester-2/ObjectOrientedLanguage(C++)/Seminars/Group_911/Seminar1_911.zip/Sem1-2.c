#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>

typedef struct {
	int elems[100];
	int length;
} vector;

/*
Write a C application with a menu based console interface which:
a. Reads a sequence of integer numbers, until 0 is encountered and prints the sum of all
read numbers.
b. Given a vector of numbers, finds the longest contiguous subsequence such that all
elements are equal.
*/

void printMenu()
{
	printf("0. Exit\n");
	printf("1. Sum of the numbers until 0\n");
	printf("2. The longest contigous sequence of equal numbers\n\n");
}

int readNumber(char *message)
{
	int number;
	printf(message);
	scanf("%d", &number);
	return number;
}

int sumOfNumbersUntilZero()
{
	int sum = 0;
	int number = -1;
	
	printf("Enter numbers to sum (ended with 0): ");
	while (number != 0)
	{
		scanf("%d", &number);
		sum += number;
	}

	return sum;
}

vector readVector() {
	vector v;
	v.length = readNumber("Enter the size of the vector: ");
	printf("Enter elements: \n");
	for (int i = 0; i < v.length; i++) {
		v.elems[i] = readNumber("");
	}
	return v;
}

vector findLongestSubsequence(vector v) {
	vector ans;
	ans.length = 0;
	int start = 0;
	int ansStart = 0;
	for (int i = 0; i < v.length; i++) {
		if (i == 0 || v.elems[i] == v.elems[i-1]) {
			int len = i - start + 1;
			if (len > ans.length) {
				ansStart = start;
				ans.length = len;
			}
		}
		else {
			start = i;
		}
	}
	for (int i = 0; i < ans.length; i++) {
		ans.elems[i] = ansStart + i;
	}
	return ans;
}

void printVector(vector v) {
	printf("The elements of the vector are: \n");
	for (int i = 0; i < v.length; i++) {
		printf("%d ", v.elems[i]);
	}
	printf("\n");
}

void longestSubsequenceEqualElems()
{
	vector v = readVector();
	vector ans = findLongestSubsequence(v);
	printVector(ans);
}

void ui()
{
	while (1)
	{
		printMenu();
		int command = 0;
		command = readNumber("Enter command: ");

		switch (command)
		{
		case 0:
			return;
		case 1:
			int sum = sumOfNumbersUntilZero();
			printf("The sum is: %d\n", sum);
			break;
		case 2:
			longestSubsequenceEqualElems();
			break;
		default:
			printf("Command was invalid!\n\n");
			break;
		}
	}
}

int main()
{
	ui();
	return 0;
}