#pragma once
#include "Repository.h"

class Service {
private:
	Repository& repository;
public:
	Service(Repository& repository) : repository(repository) {}
	std::vector<Song> getElements();
	void savePlaylist();
};
