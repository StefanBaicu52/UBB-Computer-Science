#define _CRT_SECURE_NO_WARNINGS
#include "Song.h"
#include <iostream>
#include <vector>
#include "Utils.h"

using namespace std; 

Song::Song(string artist, string title, const Duration &duration) : duration(duration) {
	this->artist = artist;
	this->title = title;
}

Song::Song()
{
	this->artist[0] = '\0';
	this->title[0] = '\0';
}
string Song::getString() {
	string myString{""};
	myString += this->title;
	myString += " ";
	myString += this->artist;
	return myString;
}

istream & operator >> (istream &is, Song &s) {
	string input;
	
	getline(is, input);

	vector<string> result = tokenize(input, ',');
	if (result.size() != 3)
		return is;

	s.setTitle(result[0]);
	s.setArtist(result[1]);

	vector<string> duration = tokenize(result[2], ':');
	Duration dur { stoi(duration[0]), atoi(duration[1].c_str()) };

	s.setDuration(dur);

	return is;
}

ostream &operator << (ostream &os, Song &s)
{
	os << s.title << "," << s.artist << "," << s.duration.minutes << ":" << s.duration.seconds;
	return os;
}