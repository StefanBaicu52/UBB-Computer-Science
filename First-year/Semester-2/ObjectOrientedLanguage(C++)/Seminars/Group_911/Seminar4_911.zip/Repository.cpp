#include "Repository.h"
#include <fstream>
#include "Exceptions.h"

Repository::Repository(string filePath, int choice) {
	this->filePath = filePath;
	this->choice = choice;
	readFromFile();
}

void Repository::add(const Song &s) {
	this->elements.push_back(s);
	writeToFile();
}

std::vector<Song> Repository::getElements(){
	return this->elements;
}

void Repository::savePlaylist() {

	if (choice == 1)
	{
		this->playlistPath = "playlist.html";
		writeToHTML();

	}
	else if (choice == 2)
	{
		this->playlistPath = "playlist.csv";
		writeToCSV();
	}
	else
		throw RepositoryException("Playlist file not chosen properly!");
}

void Repository::readFromFile() {
	ifstream is(this->filePath);
	if (is.is_open() == false) return;
	Song song;
	while (is >> song) {
		add(song);
	}
	is.close();
}

void Repository::writeToFile() {
	ofstream os(this->filePath);
	if (os.is_open() == false) return;
	for (auto &el : elements) {
		os << el;
		os << "\n";
	}
	os.close();
}

void Repository::writeToCSV() {
	ofstream os(this->playlistPath);
	if (os.is_open() == false) return;
	for (auto &el : elements) {
		os << el;
		os << "\n";
	}
	os.close();
}

void Repository::writeToHTML() {
	ofstream os(this->playlistPath);
	if (os.is_open() == false) return;
	for (auto &el : elements) {
		os << "<song>";
		os << "<artist>" << el.getArtist() << "</artist>";
		os << "<title>" << el.getTitle() << "</title>";
		os << "<duration>" 
			<< "<minutes>" << el.getDuration().minutes << "</minutes>"
			<< "<seconds>" << el.getDuration().seconds << "</seconds>"
			<< "</duration>";
		os << "</song>";
	}
	os.close();
}