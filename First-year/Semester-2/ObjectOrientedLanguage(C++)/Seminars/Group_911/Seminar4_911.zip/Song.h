#pragma once
#include <string>

using namespace std;

struct Duration {
public:
	int minutes;
	int seconds;
	Duration(int minutes = 0, int seconds = 0) : minutes{ minutes }, seconds{ seconds } {};
};

class Song {
private:
	string artist;
	string title;
	Duration duration;
public:
	Song(string artist, string title, const Duration &duration);
	Song();
	string getString();
	void setTitle(string title) { this->title = title; }
	void setArtist(string artist) { this->artist = artist; }
	void setDuration(Duration duration) { this->duration = duration; }
	string getTitle() { return this->title; }
	string getArtist() { return this->artist; }
	Duration getDuration() { return this->duration; }
	friend istream& operator >> (istream& is, Song& s);
	friend ostream &operator << (ostream &os, Song &s);
};