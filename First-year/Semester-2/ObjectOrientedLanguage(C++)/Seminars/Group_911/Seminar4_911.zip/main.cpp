#include <iostream>
#include "UI.h"
#include <string>
#include "Utils.h"

int main()
{
    // TODO: move to UI
    cout << "1. HTML\n";
    cout << "2. CSV\n";
    cout << "Please enter your choice: ";
    int choice;
    cin >> choice;
    //TODO: exception handling 



    Repository repo {"songs.txt", choice}; // pass the choice
    Service service{ repo };

    UI ui{service};
    ui.start();
    
    /*cout << "Enter song: ";
    Song song;
    cin >> song;
    cout << song;*/

    return 0;
}