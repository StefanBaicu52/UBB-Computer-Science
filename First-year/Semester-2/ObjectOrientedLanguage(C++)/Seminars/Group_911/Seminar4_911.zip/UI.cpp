#include "UI.h"
#include <iostream>
#include "Exceptions.h"

using namespace std;

void UI::start()
{
	while (true)
	{
		printMenu();
		int command;
		cin >> command;
		switch (command) {
		case 0:
			return;
		case 1:
			printAll();
			break;
		case 2:
			savePlaylist();
			break;
		}
	}
}

void UI::printMenu() {
	cout << "0 - Exit\n";
	cout << "1 - Print All\n";
	cout << "2 - Save Playlist\n";
	cout << "Enter command: ";
}

void UI::savePlaylist() {
	try {
		this->service.savePlaylist();
	}
	catch (RepositoryException e) {
		cout << e.what() << endl;
	}
}

void UI::printAll() {
	vector<Song> mySongs2 = this->service.getElements();
	for (int i = 0; i < mySongs2.size(); i++) {
		cout << mySongs2[i] << '\n';
	}
}