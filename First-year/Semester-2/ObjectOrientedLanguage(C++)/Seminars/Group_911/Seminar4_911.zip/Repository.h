#pragma once
#include "DynamicArray.h"
#include "Song.h"

class Repository {
private:
	std::vector<Song> elements;
	std::string filePath;
	std::string playlistPath;
	int choice;
public:
	Repository(std::string filePath, int choice);
	void add(const Song &s);
	std::vector<Song> getElements();
	void savePlaylist();
private:
	void readFromFile();
	void writeToFile();
	void writeToHTML();
	void writeToCSV();
};