#include "Service.h"

std::vector<Song> Service::getElements() {
	return this->repository.getElements();
}

void Service::savePlaylist() {
	this->repository.savePlaylist();
}