#include "Repository.h"


void Repository::add(const Song &s) {
	this->array.add(s);
	this->elements.push_back(s);
}

std::vector<Song> Repository::getElements(){
	return this->elements;
}

const DynamicArray<Song> &Repository::getSongs(){
	return this->array;
}
