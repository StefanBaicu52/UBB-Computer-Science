#include <iostream>
#include "UI.h"

int main()
{
    Repository repo {};
    Service service{ repo };

    Song s{ "a1", "t1", { 1, 1 } };
    repo.add(s);    // Careful for the references (Repository&)

    UI ui{service};
    ui.start();
    return 0;
}