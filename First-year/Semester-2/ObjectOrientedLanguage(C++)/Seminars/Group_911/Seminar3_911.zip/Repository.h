#pragma once
#include "DynamicArray.h"
#include "Song.h"

class Repository {
private:
	DynamicArray<Song> array;
	std::vector<Song> elements;
public:
	void add(const Song &s);
	const DynamicArray<Song>& getSongs();
	std::vector<Song> getElements();

};