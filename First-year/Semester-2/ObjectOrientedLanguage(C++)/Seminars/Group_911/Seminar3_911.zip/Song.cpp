#define _CRT_SECURE_NO_WARNINGS
#include "Song.h"

Song::Song(string artist, string title, const Duration &duration) : duration(duration) {
	this->artist = artist;
	this->title = title;
}

Song::Song()
{
	this->artist[0] = '\0';
	this->title[0] = '\0';
}
string Song::getString() {
	string myString{""};
	myString += this->title;
	myString += " ";
	myString += this->artist;
	return myString;
}
