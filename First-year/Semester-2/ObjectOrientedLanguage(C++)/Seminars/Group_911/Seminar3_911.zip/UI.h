#pragma once
#include "Service.h"

class UI {
private:
	void printMenu();
	void printAll();
	Service& service;
public:
	UI(Service &service) : service(service) {}
	void start();
};