#include "UI.h"
#include <iostream>

using namespace std;

void UI::start()
{
	while (true)
	{
		printMenu();
		int command;
		cin >> command;
		switch (command) {
		case 0:
			return;
		case 1:
			printAll();
			break;
		}
	}
}

void UI::printMenu() {
	cout << "0 - Exit\n";
	cout << "1 - Print All\n";
	cout << "Enter command: ";
}

void UI::printAll() {
	cout << "DynamicArray: ";
	DynamicArray<Song> mySongs{ this->service.getSongs() };
	for (int i = 0; i < mySongs.getSize(); i++) {
		cout << mySongs
			.getElements()[i]
			.getString() << '\n';
	}

	cout << "STL vector: ";
	vector<Song> mySongs2 = this->service.getElements();
	for (int i = 0; i < mySongs2.size(); i++) {
		cout << mySongs2[i].getString() << '\n';
	}
}