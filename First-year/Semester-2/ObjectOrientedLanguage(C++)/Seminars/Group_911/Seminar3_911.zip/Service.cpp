#include "Service.h"

std::vector<Song> Service::getElements() {
	return this->repository.getElements();
}
const DynamicArray<Song>& Service::getSongs() {
	return this->repository.getSongs();
}
